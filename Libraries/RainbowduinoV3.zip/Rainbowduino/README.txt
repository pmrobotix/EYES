Arduino 1.0 libraries for Rainbowduino (3.0)
from http://www.seeedstudio.com/wiki/images/4/43/Rainbowduino_for_Arduino1.0.zip
**************************************************

Change the 33th line in Rainbowduino.h "#include <WProgram.h>" to "#include <Arduino.h>"


15/2/2012 by Frankie at Seeedstuio.
www.seeedstudio.com
**************************************************